import { warn } from "../simple-mobile.js";
import { Controls } from "./Controls.js";
import { MODULE_NAME } from "./settings.js";
export let readyHooks = async () => {
    Hooks.on('preRenderActorSheet5eCharacter', () => {
        const container = document.querySelector('. container');
        container.scrollTop;
        container.scrollLeft;
    });
    Hooks.on('canvasInit', () => {
        if (game.settings.get(MODULE_NAME, 'performanceop') && window.screen.width < 1080) {
            var node = document.getElementById("board");
            if (node.parentNode) {
                node.parentNode.removeChild(node);
            }
            console.log("performance optimised");
            let mi = document.querySelector("#mobile-container");
        }
    });
    Hooks.on('canvasReady', function () {
        function opencontrols() {
            let controls = new Controls();
            controls.openDialog();
        }
        opencontrols();
        let charname = game.user.name;
        console.log("mobile initialised");
        document.getElementById('board').ontouchstart = function (event) {
            console.log("Touchstart");
            var x = event.touches[0].clientX;
            var y = event.touches[0].clientY;
            console.log("Moving Canvas to: " + "X:" + x + " Y:" + y);
            let options = {
                animationSpeed: 250,
                panSpeed: 100 // The panning speed in pixels per second, only used if animationSpeed is not specified
            };
            let tapcameraspeed = parseInt(game.settings.get(MODULE_NAME, 'cps'));
            let view = canvas.scene._viewPosition;
            if (x <= screen.width / 3) {
                view.x -= tapcameraspeed;
            }
            else if (x >= screen.width - screen.width / 3) {
                view.x += tapcameraspeed;
            }
            if (y <= screen.height / 4) {
                view.y -= tapcameraspeed;
            }
            else if (y >= screen.height - screen.height / 4) {
                view.y += tapcameraspeed;
            }
            canvas.animatePan({ duration: 25, x: view.x, y: view.y, scale: view.scale });
            console.log("canvas moved");
        };
        canvas.tokens.ownedTokens.length;
    });
};
export let initHooks = () => {
    warn("Init Hooks processing");
    // lets makes make this specificity stupid
};
